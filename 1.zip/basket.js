"use strict";

const basketCountEl = document.querySelector('.cartIconWrap span');
const basketTotalValueEl = document.querySelector('.basketTotalValue');
const basketTotalEl = document.querySelector('.basketTotal');
const basketEl = document.querySelector('.basket');

document.querySelector('.cartIconWrap').addEventListener('click', () => {
  basketEl.classList.toggle('hidden');
});

const basket = {};

document.querySelector('.featuredItems').addEventListener('click', event => {
  if (!event.target.closest('.addToCartBtn')) {
    return;
  }
  const featuredItem = event.target.closest('.featuredItem');
  const id = +featuredItem.dataset.id;
  const name = featuredItem.dataset.name;
  const price = +featuredItem.dataset.price;
  addToCart(id, name, price);
});

/**
 * Добавление товара в корзину
 * @param {Integer} id - номер товара
 * @param {String} name - название товара
 * @param {Number} price - товара
 */
function addToCart(id, name, price) {
  if (!(id in basket)) {
    basket[id] = {
      id: id,
      name: name,
      price: price,
      count: 0,
    }
  }
  basket[id].count++;
  basketCountEl.textContent = getTotalBasketCount().toString();
  basketTotalValueEl.textContent = getTotalBasketPrice().toFixed(2);
  renderProductInBasket(id);
}

/**
 * Получить количество товаров в корзине
 * @returns {String} - количество товаров в коризне
 */
function getTotalBasketCount() {
  return Object.values(basket).reduce((acc, product) => acc + product.count, 0);  
}

/**
 * Получить цену высех товаров в корзине
 * @returns {String}
 */
function getTotalBasketPrice() {
  return Object.values(basket).reduce((acc, product) => acc + product.count 
    * product.price, 0); 
}

/**
 * Отрисовка розины
 * @param {Number} id - номер товара
 * @returns - null
 */
function renderProductInBasket(id) {
  const basketRowEl = basketEl
    .querySelector(`.basketRow[data-id="${id}"]`);
  if (!basketRowEl) {
    renderNewProductInBasket(id);
    return;
  }

  basketRowEl.querySelector('.productCount').textContent = basket[id].count;
  basketRowEl.querySelector('.productTotalRow').textContent = basket[id].count * basket[id].price;
}

/**
 * Отрисовка отдельного товара
 * @param {Number} productId 
 */
function renderNewProductInBasket(productId) {
  const productRow = `
    <div class="basketRow" data-id="${productId}">
      <div>${basket[productId].name}</div>
      <div>
        <span class="productCount">${basket[productId].count}</span> шт.
      </div>
      <div>$${basket[productId].price}</div>
      <div>
        $<span class="productTotalRow">${(basket[productId].price * basket[productId].count).toFixed(2)}</span>
      </div>
    </div>
    `;
  basketTotalEl.insertAdjacentHTML('beforebegin', productRow)
}